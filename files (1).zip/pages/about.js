import Navbar from '../components/Navbar'
import Image from 'next/image'

export default function About() {
  return (
    <>
      <Navbar />
      <main className="max-w-2xl mx-auto p-6">
        <h2 className="text-2xl font-bold text-blue-700 mb-4">About Movello</h2>
        <Image src="/images/team.jpg" alt="Movello Team" width={600} height={400} className="rounded mb-4" />
        <p>
          Movello is a business website for Working Abroad Consulting. Our mission is to empower professionals and organizations to thrive in global environments. 
          With years of experience and a dedicated team, we guide you through every step of working or expanding abroad.
        </p>
        <ul className="list-disc ml-6 mt-4">
          <li>International career consulting</li>
          <li>Relocation and visa guidance</li>
          <li>Corporate global expansion strategies</li>
        </ul>
      </main>
    </>
  )
}