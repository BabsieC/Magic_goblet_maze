import Navbar from '../components/Navbar'

export default function Services() {
  return (
    <>
      <Navbar />
      <main className="max-w-2xl mx-auto p-6">
        <h2 className="text-2xl font-bold text-blue-700 mb-4">Our Services</h2>
        <ul className="space-y-6 mb-8">
          <li>
            <h3 className="font-semibold text-lg">Career Consulting</h3>
            <p>Personalized guidance for individuals seeking international jobs or career growth abroad.</p>
          </li>
          <li>
            <h3 className="font-semibold text-lg">Relocation Support</h3>
            <p>Visa assistance, housing, and local orientation to ensure smooth transitions to new countries.</p>
          </li>
          <li>
            <h3 className="font-semibold text-lg">Corporate Advisory</h3>
            <p>Business expansion planning, compliance, and talent acquisition for firms entering new markets.</p>
          </li>
        </ul>
        <section className="mb-8">
          <h2 className="text-xl font-bold text-blue-700 mb-4">Consulting Services Pricing</h2>
          <div className="bg-blue-50 p-4 rounded shadow">
            <ul className="space-y-2">
              <li>
                <span className="font-semibold">Career Consulting (Individuals):</span> $150/hour
              </li>
              <li>
                <span className="font-semibold">Relocation Support:</span> $200/session
              </li>
              <li>
                <span className="font-semibold">Corporate Advisory:</span> Starting at $500/project
              </li>
              <li>
                <span className="text-sm text-gray-600">*Custom packages and discounts available for long-term clients. Contact us for a detailed quote.</span>
              </li>
            </ul>
          </div>
        </section>
      </main>
    </>
  )
}