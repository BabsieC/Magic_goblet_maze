import Navbar from '../components/Navbar'

export default function Contact() {
  return (
    <>
      <Navbar />
      <main className="max-w-xl mx-auto p-6">
        <h2 className="text-2xl font-bold text-blue-700 mb-4">Contact Us</h2>
        <form className="flex flex-col space-y-4">
          <input type="text" placeholder="Your Name" className="border p-2 rounded" required />
          <input type="email" placeholder="Your Email" className="border p-2 rounded" required />
          <textarea placeholder="Your Message" className="border p-2 rounded" rows="5" required />
          <button type="submit" className="bg-blue-700 text-white px-4 py-2 rounded hover:bg-blue-800">
            Send Message
          </button>
        </form>
        <p className="mt-6 text-gray-700">
          Or email us directly at <a href="mailto:info@movello.com" className="text-blue-700 underline">info@movello.com</a>
        </p>
      </main>
    </>
  )
}