import Navbar from '../components/Navbar'

export default function Home() {
  return (
    <>
      <Navbar />
      <main className="flex flex-col items-center justify-center min-h-screen p-6">
        <h1 className="text-4xl font-bold mb-4 text-blue-700">Welcome to Movello</h1>
        <p className="text-lg max-w-2xl text-center mb-6">
          Working Abroad Consulting – Your trusted partner for navigating international careers, relocation, and global opportunities. We provide expert advice and personalized support for professionals and businesses seeking to expand abroad.
        </p>
        <a href="/services" className="bg-blue-700 text-white px-6 py-3 rounded shadow hover:bg-blue-800">
          See Our Services
        </a>
      </main>
    </>
  )
}