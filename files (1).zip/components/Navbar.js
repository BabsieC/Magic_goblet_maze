import Link from "next/link";
import Image from "next/image";

export default function Navbar() {
  return (
    <nav className="bg-blue-700 text-white px-8 py-3 flex justify-between items-center">
      <div className="flex items-center space-x-2">
        <Image src="/images/logo.png" alt="Movello Logo" width={40} height={40} />
        <span className="font-bold text-xl">Movello</span>
      </div>
      <div className="space-x-6">
        <Link href="/">Home</Link>
        <Link href="/about">About</Link>
        <Link href="/services">Services</Link>
        <Link href="/contact">Contact</Link>
      </div>
    </nav>
  );
}